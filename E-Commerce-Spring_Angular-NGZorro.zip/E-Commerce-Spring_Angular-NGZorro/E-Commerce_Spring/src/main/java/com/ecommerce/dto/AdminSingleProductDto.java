package com.ecommerce.dto;

import lombok.Data;

@Data
public class AdminSingleProductDto {

   private ProductDto productDto;

}
